import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HardCodedAuthenticationService {

  private  baseUrl = "http://localhost:9001/auth/user/login"; 

  constructor(private http: HttpClient) { }

  ngOnInit() {      
    // Simple POST request with a JSON body and response type <any>
    // this.http.post<any>(this.baseUrl,
    //    { login: 'Angular POST Request Example' }).subscribe(data => {
    //     console.log(data);
    // })
}



  login(username, password) 
  {  
    this.http.post<any>(this.baseUrl,
      { login: username, password : password }).subscribe(data => {
       console.log(data);
   })

   return true;
  }  


  authenticate(username, password){
    console.log('before '+this.isLoggedIn());

    if(username == 'Saurav' && password == '123'){
      sessionStorage.setItem('authenticatedUser', username);
      console.log('after '+this.isLoggedIn())
      return true;
    }
    return false;
  }

  isLoggedIn(){
    let user = sessionStorage.getItem('authenticatedUser');
    return !(user == null)
  }

  logOut(){
    sessionStorage.removeItem('authenticatedUser');
  }

}
