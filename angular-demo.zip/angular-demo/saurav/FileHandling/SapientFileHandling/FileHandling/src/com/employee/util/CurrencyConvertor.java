package com.employee.util;

import java.text.DecimalFormat;

public class CurrencyConvertor {

	public double getCurrency(String currency, double salary) {
		DecimalFormat f = new DecimalFormat("##.###");
		switch (currency) {
		case "INR":
			salary = Double.parseDouble((f.format(salary / 71.29)));
			break;
		case "AUD":
			salary = Double.parseDouble((f.format(salary * 0.67)));
			break;
		case "CNY":
			salary = Double.parseDouble((f.format(salary * 0.14)));
			break;
		case "GBP":
			salary = Double.parseDouble((f.format(salary * 1.21)));
			break;
		case "EUR":
			salary = Double.parseDouble((f.format(salary * 1.12)));
			break;
		default:
			salary = Double.parseDouble((f.format(salary * 0.0095)));
			break;
		}
		return salary;
	}
}
