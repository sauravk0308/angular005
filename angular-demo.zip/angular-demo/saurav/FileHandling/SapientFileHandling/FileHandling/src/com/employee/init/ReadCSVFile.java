package com.employee.init;

import java.io.IOException;

import com.employee.service.EmployeeService;

public class ReadCSVFile {
	public static void main(String[] args) throws IOException {
		EmployeeService employeeService = new EmployeeService();
		employeeService.writeAvgSalary(employeeService.getCountries());
	}
}